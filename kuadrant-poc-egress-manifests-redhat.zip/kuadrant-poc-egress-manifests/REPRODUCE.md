# Reproducing this PoC — manifest package

This package contains the manifests, scripts, and helper resources used in
the secure cross-cluster egress PoC (Kuadrant / Red Hat Connectivity Link on
OpenShift 4.20, EKS as the destination). It accompanies the design document
`REDHAT-DESIGN-AND-LIMITATIONS.md` shared separately — read that document
first; it explains *why* each piece exists and documents the limitations
found along the way. This file is only the "how to lay it down" index.

**Scope of this package: EKS destination only.** The OpenShift-to-OpenShift
destination variant and its simulated-destination materials are intentionally
excluded — this package reproduces the path that was actually measured
(source OpenShift cluster → EKS destination), the numbers in the design
document's §2.2.

## Sanitization notice

All real hostnames, cluster names, node/pod IPs, and internal domains have
been replaced with placeholders in angle brackets (e.g. `<source-cluster>`,
`<destination-fqdn>`, `<ingress-node-ip-1>`). A placeholder legend is in the
design document's header table; the short version:

| Placeholder | What it stands for |
|---|---|
| `<source-cluster>` | The OpenShift cluster the workload originates on |
| `<destination-cluster-eks>` / `<destination-fqdn>` | The EKS cluster / the FQDN the destination Gateway serves |
| `<source-app-fqdn>`, `<source-app-route-fqdn>` | Public-facing FQDNs of the source-side app |
| `<issuer-fqdn>` | The FQDN the Festival Wristband issuer (`iss` claim) is bound to |
| `<shared-wildcard-domain>` | The bank's shared wildcard DNS zone / TLS cert domain |
| `<bank-domain>` | The organization's base domain |
| `<ingress-node-ip-N>`, `<*-clusterip>`, `<*-nlb-ip>`, `<pod-ip-example-N>` | Real IPs observed during the PoC, replaced 1:1 |

**The `destino-ca` Secret's real CA certificate material has been removed
entirely** (see `poc-egress-kuadrant/origen/04-destinationrule-tls.yaml`) —
you must supply your own destination CA chain; instructions are inline in
that file. No private keys, tokens, or other key material are present
anywhere in this package — where a signing key is required (Authorino
Festival Wristband), the manifests only reference a Secret name; you
generate the key locally with `poc-egress-kuadrant/keys/gen-signing-key.sh`
and never commit or ship it.

## Prerequisites

- Source cluster: OpenShift 4.20.x with Gateway API v1 (GA) enabled and the
  `openshift-default` GatewayClass available.
- Red Hat Connectivity Link (Kuadrant) 1.3.0 (channel `stable`) installed on
  the source cluster: Kuadrant Operator, Authorino, Limitador.
- Destination cluster: EKS, with the Kuadrant upstream components installed
  per your org's applicable exception/ADR for running Kuadrant upstream (not
  RHCL) outside OpenShift — see the design document §1.3 for the exact
  versions used in this PoC.
- `oc` and/or `kubectl` CLI access to both clusters.
- `openssl` for key generation (used by `keys/gen-signing-key.sh`).
- DNS/TLS: a wildcard certificate (or per-FQDN certs) covering the FQDNs you
  substitute for the placeholders above, and a CA chain for the destination
  cluster's ingress Gateway certificate.

## Directory layout

```
poc-egress-kuadrant/
  00-smoke-wristband/    Standalone smoke test: Gateway + HTTPRoute + AuthPolicy
                          (deny-all, then wristband-issuing) to validate that
                          Authorino issues a Festival Wristband before wiring
                          up the full egress path. Includes check-token.py to
                          decode/verify the issued JWT locally.
  keys/                  gen-signing-key.sh — generates the RSA signing key
                          pair used by the wristband AuthPolicy. Produces
                          PKCS#1 ("BEGIN RSA PRIVATE KEY") output on purpose
                          — see the script's inline comments and design doc
                          ticket 2 for why PKCS#8 does not work with
                          Authorino's current key parsing.
  origen/                 Source-cluster manifests, apply in numeric order:
                          00 HTTPRoute (ingress to the app) -> 01 egress
                          Gateway -> 02 ServiceEntry (destination) -> 03
                          egress HTTPRoute -> 04 DestinationRule (mTLS/TLS
                          origination toward destination) -> 05 AuthPolicy
                          (wristband issuance) -> 06 local backend Service ->
                          07 NetworkPolicy -> 08-rollout/ (traffic-shifting
                          phases, apply one at a time) -> 09 cutover
                          (Service selector swap — the actual migration
                          trigger).
  destino/                EKS-side manifests: 10 ingress Gateway -> 11 static
                          JWKS ConfigMap+Deployment+Service (serves the
                          public key so the destination can validate
                          wristbands) -> 12 HTTPRoute -> 13a/13b two
                          alternative JWT validation approaches (Istio
                          RequestAuthentication vs. Kuadrant AuthPolicy —
                          see design doc ticket 2 for why 13b is what was
                          actually used) -> 14 RateLimitPolicy.
  alternativas/           interceptacion-externalname.yaml — fallback cutover
                          mechanism if the Gateway's dataplane pods do not
                          run inside the same namespace as the app (selector-
                          based interception then does not work); see the
                          file's own header for when to use this instead of
                          origen/09.
  pedido-jwks-eks.md      The original request/checklist used to ask the EKS
                          platform team to expose the JWKS endpoint needed by
                          destino/11.

echoserver-cascada/       Optional two-hop test harness (BFF -> backend) used
                          to validate that the egress token and cascading
                          headers survive an extra hop. Not required to
                          reproduce the core PoC; useful if you want to
                          exercise a more realistic multi-hop request shape.
                          test-cascada.sh drives it end to end.
```

## Suggested order of operations

1. Install RHCL 1.3.0 on the source OpenShift cluster and the Kuadrant
   upstream components on the destination EKS cluster (outside the scope of
   this package — follow your platform's standard installation procedure).
2. Substitute all placeholders in this package with your environment's real
   values (a simple find-and-replace across the tree is enough — every
   placeholder is a distinct `<...>` token).
3. Apply `poc-egress-kuadrant/00-smoke-wristband/` first and confirm with
   `check-token.py` that Authorino issues a valid, verifiable wristband
   before moving further — this isolates AuthPolicy/signing-key problems
   from the rest of the path.
4. Generate the signing key with `keys/gen-signing-key.sh` and wire the
   resulting Secret into `origen/05-authpolicy-wristband.yaml`.
5. Apply `destino/10` through `destino/14` on the EKS cluster so the
   destination is ready to receive and validate traffic before you cut
   anything over on the source side.
6. Apply `origen/00` through `origen/07` on the source cluster.
7. Work through `origen/08-rollout/` phases in order (mirror ->
   canary-by-header -> weighted -> weighted 50/50 -> by-method) rather than
   jumping straight to cutover — each phase is a checkpoint.
8. Apply `origen/09-cutover-service-selector.yaml` (or the
   `alternativas/interceptacion-externalname.yaml` fallback, if applicable)
   to complete the migration.

For the reasoning behind this order, the measured numbers at each stage, and
the six limitation tickets encountered along the way, see
`REDHAT-DESIGN-AND-LIMITATIONS.md`.
